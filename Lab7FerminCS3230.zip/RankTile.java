/*By Erika Fermin, CS 3230 spring 2019*/
public class RankTile extends Tile
{
	protected int rank;
	
	public RankTile(int rank)
	{
		this.rank = rank;
	}
	
	
	public boolean matches(Tile other)
	{
		if(this == other)
		{
			return true;
		}
		if(getClass() != other.getClass())
		{
			return false;
		}
		
		RankTile o = (RankTile)other;

		if(this.rank == o.rank)
		{
			return super.matches(other);
		}
		else
		{
			return false;
		}
	}
}
