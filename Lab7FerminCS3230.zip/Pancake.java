/*By Erika Fermin, CS 3230 spring 2019*/
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;

public class Pancake extends Circle
{
	private int x;
	private int y;
	private int r;
	private Color color;
	
	public Pancake(int x, int y, int r, Color color)
	{
		super(x,y,r,color);
		
		this.x = x;
		this.y = y;
		this.r = r;
		this.color = color;
	}
	
	@Override
	public void draw(Graphics g)
	{
		Graphics2D g2 = (Graphics2D)g;
		
		new Pancake(31, 15, 50, Color.decode("#008000"));
	        
		Shape circle = new Ellipse2D.Double(31, 15, 50, 50);
		g2.setClip(circle);
		g2.setPaint(Color.decode("#008000"));
		g2.fill(circle);
		
		super.draw(g);
		
	    int x = 51;
	    int y = 20;
	    for (int i = 0; i < 16; i++) 
	    {
	    	double t = 2 * Math.PI * i / 16;
	        x = (int) Math.round(x + 7 * Math.cos(t));
	        y = (int) Math.round(y + 7 * Math.sin(t));  
	            
			circle = new Ellipse2D.Double(x, y, 4, 4);
			g2.setClip(circle);
			g2.setPaint(Color.WHITE);
			g2.fill(circle);
	    }
		
	}
}
