/*By Erika Fermin, CS 3230 spring 2019*/
import	java.awt.*;
import java.awt.geom.*;

public class Circle 
{
	private int x;
	private int y;
	private int r;
	private Color color;
	
	public Circle(int x, int y, int r, Color color)
	{
		this.x = x;
		this.y = y;
		this.r = r;
		this.color = color;
	}
	
	public void draw(Graphics g)
	{
		Graphics2D g2 = (Graphics2D)g;
		
		Shape circle = new Ellipse2D.Double(x, y, r, r);
		g2.setClip(circle);
		g2.setPaint(color);
		g2.fill(circle);
		
		g2.setPaint(Color.WHITE);
		g2.draw(new Line2D.Double(x + 4, y+3, x + 2*r, y + 2*r));			
		g2.setPaint(Color.WHITE);
		g2.draw(new Line2D.Double(x + 5, y + 22, x + r*2, y - r*2));
	}

}
