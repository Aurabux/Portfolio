/*By Erika Fermin, CS 3230 spring 2019*/
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class MahJongBoard extends JPanel implements MouseListener
{
	private int[][][] mahJongBoard = 
		{ 
				   {{1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},  
					{0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
					{0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0},
					{1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
					{1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
					{1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0},
					{0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0},
					{1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}},
				   
				   {{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
					{0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0}, 
					{0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0},
					{0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0},
					{0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0},
					{0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0},
					{0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0},
					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
				   
				   {{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
					{0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0},
					{0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0},
					{0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0},
					{0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0},
					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
				   
				   {{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
					{0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0},
					{0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0},
					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
					{1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}},						   					      

		};
	
	private int zAxis = 4;
	private int yAxis = 8;
	private int xAxis = 12;
	private int zOrder1, zOrder2;
	private int clearedTiles;
	private boolean won;
	private Tile t, firstTile;
	private MahJongModel[][][] board = new MahJongModel[zAxis][yAxis][xAxis];
	private ArrayList<Tile> tiles = new ArrayList<Tile>();
	private ArrayList<Tile> removedTiles = new ArrayList<Tile>();
	private ArrayList<Tile> redoTiles = new ArrayList<Tile>();
   	Fireworks fw = new Fireworks(this);
	Image image;

	
	public MahJongBoard(int gameSeed)
	{
		
		
		//Jar
		URL img = getClass().getResource("images/year-of-the-pig.jpg");
		image = new ImageIcon(img).getImage();
		
		setLayout(null);
		createTilesList();
		createBoard(gameSeed);
		draw();
		setOpaque(true);
	}

	private void createTilesList()
	{
		for(int i = 1; i <= 9; i++)
		{
			for(int j = 0; j < 4; j++)
			{
				tiles.add(new CharacterTile(Character.forDigit(i, 10)));
			}
		}
		for(int i = 1; i <= 9; i++)
		{
			for(int j = 0; j < 4; j++)
			{
				tiles.add(new CircleTile(i));
			}
		}
		for(int i = 2; i <= 9; i++)
		{
			for(int j = 0; j < 4; j++)
			{
				tiles.add(new BambooTile(i));
			}
		}
		for(int i = 0; i < 4; i++)
		{
			tiles.add(new CharacterTile('N'));
			tiles.add(new CharacterTile('E'));
			tiles.add(new CharacterTile('W'));
			tiles.add(new CharacterTile('S'));
			tiles.add(new CharacterTile('C'));
			tiles.add(new CharacterTile('F'));
			tiles.add(new Bamboo1Tile());
			tiles.add(new WhiteDragonTile());
		}
		
		tiles.add(new FlowerTile("Chrysanthemum"));
		tiles.add(new FlowerTile("Orchid"));
		tiles.add(new FlowerTile("Plum"));
		tiles.add(new FlowerTile("Bamboo"));
		tiles.add(new SeasonTile("Spring"));
		tiles.add(new SeasonTile("Summer"));
		tiles.add(new SeasonTile("Fall"));
		tiles.add(new SeasonTile("Winter"));
		
	}
	
	private void createBoard(int gameSeed)
	{
		Collections.shuffle(tiles, new Random(gameSeed));
		
		for(int z = 0; z < zAxis; z++)
		{
			for(int y = 0; y < yAxis; y++)
			{
				for(int x = 0; x < xAxis; x++)
				{
					if(mahJongBoard[z][y][x] == 1)
					{
						board[z][y][x] = new MahJongModel(t = tiles.remove(tiles.size() - 1), x, y, z);
					}
				}
			}
		}
		
	}
	
    public void draw()
    {		   	
		for(int z = zAxis - 1; z >= 0; z--)
		{
	    	for(int y = yAxis - 1; y >= 0; y--)
			{
				for(int x = 0; x < xAxis; x++)
				{
					if(mahJongBoard[z][y][x] == 1)
					{
						t = board[z][y][x].getTile();
						t.setSize(t.tileWidth,t.tileHeight);
						t.setCoordinates(x, y, z);
						
						if(x == 0 && y == 5 && z == 0)
						{
							t.setLocation(x, y * (t.tileHeight-40) - 30);
						}
						else if(x == 10 && y == 1 && z == 0)
						{
							t.setLocation(x * (t.tileWidth-30) + 260, 4 * (t.tileHeight-35) - (z*20) + 15);
						}
						else if(x == 11 && y == 1 && z == 0)
						{
							t.setLocation(x * (t.tileWidth-30) + 265, 4 * (t.tileHeight-35) - (z*20) + 15);
						}
						else if(x == 0 && y == 7 && z == 3)
						{
							t.setLocation(470 + (z*10) + 4, y * (t.tileHeight-71) - (z*20) + 50);
						}
						else
						{
							t.setLocation(x * (t.tileWidth-25) + (z*10) + 70, y * (t.tileHeight-40) - (z*20) + 60);
						}
						
						t.addMouseListener(this);
						
						add(t);
					}
				}
			}
		}     
    }
    
    public void wonGame()
    {
    	if(clearedTiles != 144)
    	{
    		return;
    	}
    	
    	won = true;
    	removeAll();
		setBackground(Color.BLACK);
		
		JLabel label = new JLabel("Congratulations, You Won!");
		label.setFont(new Font("Verdana",1,20));
		label.setForeground(Color.RED);
		label.setLocation(500, 100);
		label.setSize(300, 300);
		add(label);
		
    	fw.setSound(true);
		fw.setExplosions(15, 1000);
		fw.fire();	
    }
    
    
    public ArrayList<Tile> getRemovedTiles()
    { 	
    	ArrayList<Tile> copy = (ArrayList<Tile>) removedTiles.clone();
    	
    	return removedTiles;
    }
    
    public void undo()
    {
    	if(removedTiles.isEmpty())
    	{
    		return;
    	}
    	
    	Tile undo1 = removedTiles.remove(removedTiles.size() - 1);
    	Tile undo2 = removedTiles.remove(removedTiles.size() - 1);
    	
		redoTiles.add(undo1);
		redoTiles.add(undo2);

    	int[] c1 = undo1.getCoordinates();
    	int[] c2 = undo2.getCoordinates();
    	
    	zOrder1 = undo1.getZOrder();
    	zOrder2 = undo2.getZOrder();
    	
		board[c1[2]][c1[1]][c1[0]] = new MahJongModel(undo1, c1[0], c1[1], c1[2]);
		board[c2[2]][c2[1]][c2[0]] = new MahJongModel(undo2, c2[0], c2[1], c2[2]);
		
		add(undo1);
		add(undo2);
		setComponentZOrder(undo1, zOrder1);
		setComponentZOrder(undo2, zOrder2);		
		
		clearedTiles -= 2;
    	
		repaint();
    }
    
    public void redo()
    {	
    	if(redoTiles.isEmpty())
    	{   		
    		return;
    	}
    	
    	Tile redo1 = redoTiles.remove(redoTiles.size() - 1);
    	Tile redo2 = redoTiles.remove(redoTiles.size() - 1);
    	
    	int[] c1 = redo1.getCoordinates();
    	int[] c2 = redo2.getCoordinates();
		
		removeTiles(redo1, c1[0], c1[1], c1[2]);
		removeTiles(redo2, c2[0], c2[1], c2[2]);
		
		clearedTiles += 2;
    	
		repaint();
    }
    
	public void mousePressed(MouseEvent e)
	{
		Tile t = (Tile)e.getSource();
		int[] c1 = t.getCoordinates();
		
		if (e.getButton() == MouseEvent.BUTTON1)
		{
			if(isTileOpen(c1[0], c1[1], c1[2]))
			{
				if(firstTile == null)
				{
					firstTile = t;
					firstTile.selected(true);

				}
				else
				{
					if(firstTile.matches(t) && differentTile(firstTile, t))
					{
						int[] c2 = firstTile.getCoordinates();
						firstTile.setZOrder(getComponentZOrder(firstTile));
						removeTiles(firstTile, c2[0], c2[1], c2[2]);
						t.setZOrder(getComponentZOrder(t));
						removeTiles(t, c1[0], c1[1], c1[2]);
						firstTile.selected(false);
						firstTile = null;
						clearedTiles += 2;
						redoTiles.clear();
						wonGame();
					}
					else if(!differentTile(firstTile, t))
					{
						firstTile.selected(false);
						firstTile = null;

					}
					else
					{
						firstTile.selected(false);
						firstTile = null;
					}
				}
			}
			repaint();
		}
	}
	
    public boolean isTileOpen(int x, int y, int z)
    {
    	boolean leftTile, rightTile, topTile;
    	
    	if(x == 0 && (y == 3 || y == 4) && z == 0)
    	{
    		leftTile = board[0][5][0] == null;
    	}
    	else
    	{
    		if(x == 0 || (x == 1 && y == 5 && z == 0))
    		{
    			leftTile = true;
    		}
    		else
    		{
    			leftTile = (x != 0)  && board[z][y][x-1] == null;
    		}
    	}
		
    	if(x == 11 && (y == 3 || y == 4) && z == 0)
    	{
    		rightTile = board[0][1][10] == null;
    	}
    	else
    	{
    		if(x == xAxis - 1 || (x == 9 && y == 1 && z == 0))
    		{
    			rightTile = true;
    		}
    		else
    		{
    			rightTile = board[z][y][x+1] == null;
    		}
    	}
    	
    	if(z == zAxis - 1)
    	{
    		if(y == 7)
    		{
    			topTile = true;
    		}
    		else
    		{
    			topTile = board[3][7][0] == null;
    		}
    	}
    	else
    	{
    		topTile = ((z != zAxis - 1)  && board[z+1][y][x] == null);
    	}
		
		return (leftTile || rightTile) && topTile;
    }
	
    public void removeTiles(Tile t, int x, int y, int z)
    {
		removedTiles.add(t);
		board[z][y][x] = null;
		remove(t);
		repaint();
    }
    
    public boolean differentTile(Tile firstTile, Tile secondTile)
    {
    	int[] ft = firstTile.getCoordinates();
    	int[] st = secondTile.getCoordinates();
    	
    	return !Arrays.equals(ft, st);
    }

	public void mouseReleased(MouseEvent e) 
	{
		
	}
	public void mouseClicked(MouseEvent e)
	{
		
	}
	public void mouseEntered(MouseEvent e)
	{
		
	} 
	public void mouseExited(MouseEvent e) 
	{
		
	}
	
	@Override
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		
		Graphics2D g2 = (Graphics2D)g;
		
		if(won == false)
		{	
			Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
			
			g2.drawImage(image, 0, 0, screenSize.width / 2 + 200, screenSize.height / 2 + 100, this);
		}
	}
}

