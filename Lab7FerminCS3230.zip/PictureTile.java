/*By Erika Fermin, CS 3230 spring 2019*/
public class PictureTile extends Tile
{
	private String name;
	
	public PictureTile(String name)
	{
		this.name = name;
		setToolTipText(toString());
	}
	
	public String toString()
	{
		return name;
	}
}
