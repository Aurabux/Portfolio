/*By Erika Fermin, CS 3230 spring 2019*/
public class MahJongModel
{
	public Tile t;
	int x, y, z, zOrder;
	
	public MahJongModel(Tile t, int x, int y, int z)
	{
        this.t = t;
        this.x = x;
        this.y = y;
        this.z = z;
	}
	
	public Tile getTile()
	{
		return t;
	}
	
    public int getX()
    {
        return x;
    }
    
    public int getY()
    {
        return y;
    }
    
    public int getZ()
    {
        return z;
    }
	
}
