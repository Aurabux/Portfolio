/*By Erika Fermin, CS 3230 spring 2019*/
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.net.URL;
import javax.swing.ImageIcon;

public class FlowerTile extends PictureTile
{
	Image image;
	
	public FlowerTile(String name)
	{
		super(name);
		setToolTipText(toString());
	
		URL img = getClass().getResource("images/" + name + ".png");
		image = new ImageIcon(img).getImage();
	}
	
	@Override
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		
		Graphics2D g2 = (Graphics2D)g;
		
		this.getClass().getResource("images/images.jar");
		
		g2.drawImage(image, 30, 15, 50, 50, null);
		
	}
	
}
