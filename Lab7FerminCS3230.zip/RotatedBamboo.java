/*By Erika Fermin, CS 3230 spring 2019*/
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;

public class RotatedBamboo extends Bamboo
{
	private int d;
	
	public RotatedBamboo(int d, int x, int y, Color color)
	{
		super(x, y, color);
		this.d = d;

	}

	@Override
	public void draw(Graphics g)
	{
		Graphics2D g2 = (Graphics2D)g;
		
		AffineTransform t = g2.getTransform();
		g2.rotate(Math.toRadians(d));
		
		super.draw(g);
		
		g2.setTransform(t);
			
	}
	
	
}
