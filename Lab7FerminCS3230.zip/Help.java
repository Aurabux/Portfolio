import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.util.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.text.*;

public class Help extends JPanel implements HyperlinkListener
{
	private	JEditorPane	text = new JEditorPane();
	private	JScrollPane	scroller = new JScrollPane();
	private	JPanel		controls = new JPanel();
	private	Stack<URL>	backStack = new Stack<URL>();
	private	Stack<URL>	forwardStack = new Stack<URL>();
	private	JFrame		frame = null;
	private	URL		currentURL = null;
	private	JButton		back = null;
	private	JButton		next = null;
   



	public Help(String file, String title)
	{
		this(file);

		frame = new JFrame();
	

		frame.addWindowListener(new WindowAdapter()
		{	public void windowClosing(WindowEvent event)
				{ frame.setVisible(false); }
		});

	
		frame.add(this);

		frame.setSize(800,600);
		frame.setTitle(title);
	}


	/**
	 * Builds a help a help system in the form of a panel that can be displayed in a frame, a panel,
	 * a dialog, or other container.
	 * The panel has back and forward buttons at the bottom that displays the previous and the next help files.
	 * @param file The name of the file containing the HTML formatted help/instructions.
	 */

	public Help(String file)
	{
		setLayout(new BorderLayout());
		scroller.setViewportView(text);
		add(scroller);
		text.addHyperlinkListener(this);
		readHTML(file);

		add(controls, BorderLayout.SOUTH);
	}


	/**
	 * Pushes the current help page on a stack and displays a new page selected when the
	 * user clicks on a hyperlink.  Selecting a new hyperlink invalidates all current links
	 * in the forward stack.
	 * This method is required by the HyperlinkListener interface.
	 * @param e The hyperlink event.
	 */

	public void hyperlinkUpdate(HyperlinkEvent e)
	{
		try
		{
			if (e.getEventType() == HyperlinkEvent.EventType.ACTIVATED)
			{
				backStack.push(currentURL);
				currentURL = e.getURL();
				text.setPage(currentURL);
				back.setEnabled(true);
				next.setEnabled(false);
				forwardStack.clear();
			}
		}
		catch (IOException ioe)
		{
			JOptionPane.showMessageDialog(this, "Unable to load page:\n" +
				e.getDescription(),
				"Help Error", JOptionPane.ERROR_MESSAGE);
		}
	}


	/**
	 * Displays the previous help information.
	 */

	public void back()
	{
		try
		{
			forwardStack.push(currentURL);

			currentURL = backStack.pop();
			text.setPage(currentURL);

			if (backStack.empty())
				back.setEnabled(false);
			next.setEnabled(true);
		}
		catch (IOException ioe)
		{
			JOptionPane.showMessageDialog(this, "Unable to reload previous page",
				"Help Error", JOptionPane.ERROR_MESSAGE);
		}
	}


	/**
	 * Advances to the next help page saved when the "back" button was pressed.
	 */

	public void forward()
	{
		try
		{
			backStack.push(currentURL);

			currentURL = forwardStack.pop();
			text.setPage(currentURL);

			if (forwardStack.empty())
				next.setEnabled(false);
			back.setEnabled(true);
		}
		catch (IOException ioe)
		{
			JOptionPane.showMessageDialog(this, "Unable to reload next page",
				"Help Error", JOptionPane.ERROR_MESSAGE);
		}
	}
	

	
	public void close()
	{
		frame.setVisible(false);
		backStack.clear();
		forwardStack.clear();
	}


	

	public void display()
	{
		frame.setVisible(true);
	}



	public void conceal()
	{
		frame.setVisible(false);
	}


	

	private void readHTML(String file)
	{
		try
		{
			Document doc = text.getDocument();
			text.setEditable(false);

			currentURL = Help.class.getResource(file);
			text.setPage(currentURL);
		}
		catch (FileNotFoundException FNF)
		{
			JOptionPane.showMessageDialog(this, "Unable to locate help file " + file,
				"Help Error", JOptionPane.ERROR_MESSAGE);
		}
		catch (IOException ioe)
		{
			JOptionPane.showMessageDialog(this, "Unable to locate help file " + file,
				"Help Error", JOptionPane.ERROR_MESSAGE);
		}
	}
}

