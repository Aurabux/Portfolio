/*By Erika Fermin, CS 3230 spring 2019*/
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Stroke;

public class WhiteDragonTile extends Tile
{
	public WhiteDragonTile()
	{
		setToolTipText(toString());
	}
	
	public String toString()
	{
		return "White Dragon";
	}
	
	@Override 
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		
		Graphics2D g2 = (Graphics2D)g;
		
		Stroke s = new BasicStroke(6f,BasicStroke.CAP_SQUARE, BasicStroke.JOIN_MITER, 10f, new float[]{1f,1f}, 1f);
		
		g2.setStroke(s);
		
		g2.setPaint(Color.WHITE);
		
		Rectangle r = new Rectangle(29, 19,55,45);
		g2.draw(r);
		
		s = new BasicStroke(6f,BasicStroke.CAP_SQUARE, BasicStroke.JOIN_MITER, 10f, new float[]{3f,15f}, 1f);
		
		g2.setStroke(s);
		
		g2.setPaint(Color.BLUE);
		
		r = new Rectangle(29, 19,55,45);
		g2.draw(r);
		
		g2.setStroke(new BasicStroke());
		r = new Rectangle(25,15,60,50);
		g2.draw(r);
		
		r = new Rectangle(30, 20, 50, 40);
		
		g2.draw(r);
		
	}
}
