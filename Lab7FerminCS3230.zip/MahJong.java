/*By Erika Fermin, CS 3230 spring 2019*/
import	java.awt.*;
import	java.awt.event.*;
import	java.util.*;
import java.util.List;
import	javax.swing.*;
import	java.awt.*;
import	java.awt.event.*;
import	javax.swing.*;
import	java.beans.*;
import javax.swing.JTextField;
import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;


public class MahJong extends JFrame 
{
   private MahJongBoard board;
   private int gameSeed;
   public boolean tournament;
   JScrollPane scrollPane = new JScrollPane();
   Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
   Timer t;

   public MahJong()
   {
      //toggles
      tournament = false;
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      setTitle("Mah Jong Tiles Demo");
   	
      gameSeed = (int) System.currentTimeMillis();
   	
      setPreferredSize(new Dimension(screenSize.width / 2 + 200, screenSize.height / 2 + 100));
   	
      setLayout(new BorderLayout());
      board = new MahJongBoard(gameSeed);
      makeMenu();
      add(board, BorderLayout.CENTER);
        
      setResizable(false);
        
      pack();
      setVisible(true);
   }
	
   private void makeMenu()
   {
      JMenuBar	menuBar = new JMenuBar();
      setJMenuBar(menuBar);
   
      JMenu fileMenu = makeMenu("File");
      menuBar.add(fileMenu);
   	
      fileMenu.add(makeMenuItem("New Game", 'N', "new game", this));
   	
      fileMenu.add(makeMenuItem("Restart", 'R', "restart", this));
   	
      fileMenu.addSeparator();
   	
      fileMenu.add(makeMenuItem("Exit", 'E', "exit", this));
   	
      JMenu editMenu = makeMenu("Edit");
      menuBar.add(editMenu);
   	
      editMenu.add(makeMenuItem("Undo", "ctrl Z", 'U', "undo", this));
      editMenu.add(makeMenuItem("Redo", "ctrl Y", 'R', "redo", this));
      
      //# Game
      JMenu gameNum = new JMenu("Game#");
      menuBar.add(gameNum);
      JMenuItem enterSeed = new JMenuItem("Enter Seed");
      enterSeed.addActionListener(
         new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
               String userNum;
               userNum = JOptionPane.showInputDialog("Enter Game Seed.");
               int result = Integer.parseInt(userNum); 
               restart(result);    
            }
         });
      gameNum.add(enterSeed);
      //extra cred
      JMenu tournamentMenu = new JMenu("Tournament");
      menuBar.add(tournamentMenu);
   
      JMenuItem tournamentItem = new JMenuItem("Start Tourament");
      tournamentItem.addActionListener(
         new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
               toggleTournament();
            }
         });
      tournamentMenu.add(tournamentItem);
   
     
      //Help
      JMenu help = new JMenu("Help");
      menuBar.add(help);
   
        //Operation
      JMenuItem operation = new JMenuItem("Operation");
      operation.addActionListener(
         new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
               Help h = new Help("help/help.html", "Help");
               h.display();
            }
         });
      help.add(operation);
        
        //Rules
      JMenuItem rules = new JMenuItem("Game Rules");
      rules.addActionListener(
         new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
               Help h = new Help("help/rules.html", "Help");
               h.display();
            }
         });
      help.add(rules);
      
      menuBar.add(Box.createHorizontalGlue());
      Action toggleAction = 
         new AbstractAction("Toggle Removed Tiles Panel On") {
            @Override
            public void actionPerformed(ActionEvent e) 
            {
               AbstractButton button = (AbstractButton)e.getSource();
              
               if (button.isSelected())
               {
                  button.setText("Toggle Removed Tiles Panel Off");
               
                  makeScrollPane();
               } 
               else 
               {
                  button.setText("Toggle Removed Tiles Panel On");
               
                  remove(scrollPane);
               }
            }
         };
   	
      menuBar.add(new JToggleButton(toggleAction));
   }
	
   private void makeScrollPane()
   {
      scrollPane.setBorder(BorderFactory.createTitledBorder("Removed"));
   
      ArrayList<Tile> tiles = board.getRemovedTiles();
      JList<Tile> list = new JList(tiles.toArray());
   
      scrollPane.setViewportView(list);
        
      scrollPane.setPreferredSize(new Dimension(90, screenSize.height / 2 + 100));
      add(scrollPane, BorderLayout.EAST);
   
   }
	
   private JMenuItem makeMenuItem(String label, char mnemonic, String method, Object target)
   {
      JMenuItem	menuItem = new JMenuItem(label, mnemonic);
   
      menuItem.addActionListener(
         new ActionListener()
         {
            public void actionPerformed(ActionEvent e)
            {
               if(label == "New Game")
               {
                  gameSeed = (int) System.currentTimeMillis();
                  restart(gameSeed);
               }
               else if(label == "Restart")
               {
                  restart(gameSeed);
               }
               else if(label == "Undo")
               {
                  board.undo();
               }
               else if(label == "Redo")
               {
                  board.redo();
               }
               else if(label == "Exit")
               {
                  exit();
               }
            }
         });
   
   
   
      return menuItem;
   }
	
   private JMenuItem makeMenuItem(String label, String accelerator, char mnemonic, String method, Object target)
   {
      JMenuItem	menuItem = new JMenuItem(label, mnemonic);
   
      menuItem.setAccelerator(KeyStroke.getKeyStroke(accelerator));
   	
      menuItem.addActionListener(
         new ActionListener()
         {
            public void actionPerformed(ActionEvent e)
            {
               if(label == "Undo")
               {
                  board.undo();
               }
               else if(label == "Redo")
               {
                  board.redo();
               }
             
            }
         });
   
      return menuItem;
   }
	
   public void exit() 
   {
      if (JOptionPane.showConfirmDialog(this, "Do you want to end this program?", "End Program", 
      		JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE) == JOptionPane.OK_OPTION)
      {
         System.exit(0);
      }
   }
	
   private void restart(int gameSeed)
   {
      remove(board);
      board = new MahJongBoard(gameSeed);
      setTitle(Integer.toString(gameSeed));
      add(board, BorderLayout.CENTER);
      revalidate();
      repaint();
   }
	
   private JMenu makeMenu(String label)
   {
      JMenu	menu = new JMenu(label);
      return menu;
   }
	//extra cred
   private void toggleTournament()
   {
      tournament = !tournament;
      if(tournament){
         gameSeed = (int) System.currentTimeMillis();
         restart(gameSeed);
         setTitle("Mah Jong - Tournament Mode");
         t = new Timer();
         add(t, BorderLayout.NORTH);
      } else {
         gameSeed = (int) System.currentTimeMillis();
         remove(t);
      }
   }
   public static void main(String[] args)
   {
      new MahJong();
   	
   }
}
