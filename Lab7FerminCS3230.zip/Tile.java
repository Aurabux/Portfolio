/*By Erika Fermin, CS 3230 spring 2019*/
import	java.awt.*;
import java.util.ArrayList;

import	javax.swing.*;

public class Tile extends JPanel
{
	public int tileWidth = 95;
	public int tileHeight = 100;
	private int x, y, z, zOrder;
	private boolean selected;
	
	public Tile()
	{
		setPreferredSize(new Dimension(tileWidth, tileHeight));
	}
	
	public void setCoordinates(int x, int y, int z)
	{
		this.x = x;
		this.y = y;
		this.z = z;
	}
	
	public int[] getCoordinates()
	{
		int [] c = {x, y, z};
		
		return c;
	}
	
	public void setZOrder(int zOrder)
	{
		this.zOrder = zOrder;
	}
	
	public int getZOrder()
	{
		return zOrder;
	}
	
	
	public void selected(boolean selected)
	{
		this.selected = selected;
	}
	
	@Override
      public void paintComponent(Graphics g) 
   {	
      setSize(new Dimension(tileWidth, tileHeight));
   		
      Graphics2D g2 = (Graphics2D)g;
    
   
      GradientPaint grad1 = new GradientPaint(10, 90, Color.PINK, 20, 10, Color.decode("#F73BAC"));
   		
      Polygon left = new Polygon();
      left.addPoint(20, 10);
      left.addPoint(10, 30);
      left.addPoint(10, 90);
      left.addPoint(20, 70);
      g2.setPaint(grad1);
      g2.fillPolygon(left);
      g2.setPaint(Color.BLACK);
      g2.drawPolygon(left);
   		
      GradientPaint grad2 = new GradientPaint(15, 80, Color.WHITE, 20, 10, Color.decode("#FFEBCD"));
   		
      Polygon leftMid = new Polygon();
      leftMid.addPoint(20, 10);
      leftMid.addPoint(15, 20);
      leftMid.addPoint(15, 80);
      leftMid.addPoint(20, 70);
      g2.setPaint(grad2);
      g2.fillPolygon(leftMid);
      g2.setPaint(Color.BLACK);
      g2.drawPolygon(leftMid);
   		
      GradientPaint grad3 = new GradientPaint(10, 90, Color.PINK, 85, 80, Color.decode("#F73BAC"));
   		
      Polygon bottom = new Polygon();
      bottom.addPoint(15, 80);
      bottom.addPoint(10, 90);
      bottom.addPoint(80, 90);
      bottom.addPoint(85, 80);
      g2.setPaint(grad3);
      g2.fillPolygon(bottom);
      g2.setPaint(Color.BLACK);
      g2.drawPolygon(bottom);
   		
      GradientPaint grad4 = new GradientPaint(15, 80, Color.WHITE, 90, 70, Color.decode("#FFEBCD"));
   		
      Polygon bottomMid = new Polygon();
      bottomMid.addPoint(20, 70);
      bottomMid.addPoint(15, 80);
      bottomMid.addPoint(85, 80);
      bottomMid.addPoint(90, 70);
      g2.setPaint(grad4);
      g2.fillPolygon(bottomMid);
      g2.setPaint(Color.BLACK);
      g2.drawPolygon(bottomMid);
   		
   		
      GradientPaint grad5 = new GradientPaint(20, 90, Color.WHITE, 70, 10, Color.decode("#FFEBCD"));
   			
      g2.setPaint(grad5);
      g.drawRect(20, 10, 70, 60);
      g.fillRect(20, 10, 70, 60);
      g2.setPaint(Color.BLACK);
      g.drawRect(20, 10, 70, 60);
   		
		
		if(selected)
		{
			Stroke s = new BasicStroke(6f,BasicStroke.CAP_SQUARE, BasicStroke.JOIN_MITER, 10f, new float[]{1f,1f}, 1f);
			
			g2.setStroke(s);
			
			g2.setPaint(Color.RED);
			
			Rectangle r = new Rectangle(23, 13, 65, 55);
			g2.draw(r);
			
			s = new BasicStroke(6f,BasicStroke.CAP_SQUARE, BasicStroke.JOIN_MITER, 10f, new float[]{3f,15f}, 1f);
			
			g2.setStroke(new BasicStroke());
			r = new Rectangle(20,10,70,60);
			g2.draw(r);
			
			r = new Rectangle(25, 15, 60, 50);
			
			g2.draw(r);
		}
		
		g.drawRect(20, 10, 70, 60);
	}
	
	public boolean matches(Tile other)
	{
		if(this.getClass() == other.getClass())
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}

