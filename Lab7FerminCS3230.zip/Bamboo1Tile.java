/*By Erika Fermin, CS 3230 spring 2019*/
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.net.URL;

import javax.swing.ImageIcon;

public class Bamboo1Tile extends PictureTile
{
	Image image;
	
	public Bamboo1Tile()
	{
		super("Sparrow");
		setToolTipText(toString());

		URL img = getClass().getResource("images/Sparrow.png");
		image = new ImageIcon(img).getImage();
	}

	public String toString()
	{
		return "Bamboo 1";
	}
	
	@Override
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		
		Graphics2D g2 = (Graphics2D)g;
		
		this.getClass().getResource("images/images.jar");
		
		g2.drawImage(image, 30, 15, 50, 50, null);
		
	}
}
