/*By Erika Fermin, CS 3230 spring 2019*/
import	java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.geom.GeneralPath;

public class Bamboo
{
	private int x;
	private int y;
	private Color color;
	
	
	public Bamboo(int x, int y, Color color)
	{
		this.x = x;
		this.y = y;
		this.color = color;
	}
	
	public void draw(Graphics g)
	{
		Graphics2D g2 = (Graphics2D)g;
		
		int xPoints[] = {x-3,x-3,x-4,x-4,x-2,x-2,x-3,x-3,x-4,x-4,x-2,x-2,x-3,x-3,x-4,x-4,
				   x+4,x+4,x+3,x+3,x+2,x+2,x+4,x+4,x+3,x+3,x+2,x+2,x+4,x+4,x+3,x+3};
		int yPoints[] = {y+10,y+9,y+9,y+7,y+7,y+5,y+5,y+4,y+4,y-1,y-1,y-3,y-3,y-4,y-4,y-5,
						 y-5,y-4,y-4,y-3,y-3,y-1,y-1,y+4,y+4,y+5,y+5,y+7,y+7,y+9,y+9,y+10};
		
		GeneralPath Bamboo = new GeneralPath(GeneralPath.WIND_EVEN_ODD, xPoints.length);
		
		Bamboo.moveTo(xPoints[0], yPoints[0]);
		
		for(int i = 1; i < xPoints.length; i++)
		{
			Bamboo.lineTo(xPoints[i], yPoints[i]);
		}
		
		Bamboo.closePath();
		g2.setColor(color);
		g2.fill(Bamboo);
		
		g2.setColor(Color.WHITE);
		g2.drawLine(x, y-1, x, y-6);
		g2.drawLine(x, y+3, x, y+9);
	}

}
