/*By Erika Fermin, CS 3230 spring 2019*/
import	java.awt.*;
import 	java.util.HashMap;

public class CharacterTile extends Tile
{
	protected char symbol;
	
	HashMap<Character, Character> hMap = new HashMap<Character, Character>();
	
	public CharacterTile(char symbol)
	{
		this.symbol = symbol;
		setToolTipText(toString());
	}
	
	@Override
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		
		Graphics2D g2 = (Graphics2D)g;
		
		g2.setColor(Color.RED);
		g2.drawString(Character.toString(symbol), 78, 26);
		
		hMap.put('1', '\u4E00');
		hMap.put('2', '\u4E8C');
		hMap.put('3', '\u4E09');
		hMap.put('4', '\u56DB');
		hMap.put('5', '\u4E94');
		hMap.put('6', '\u516D');
		hMap.put('7', '\u4E03');
		hMap.put('8', '\u516B');
		hMap.put('9', '\u4E5D');
		hMap.put('N', '\u5317');
		hMap.put('E', '\u6771');
		hMap.put('W', '\u897F');
		hMap.put('S', '\u5357');
		hMap.put('C', '\u4E2D');
		hMap.put('F', '\u767C');
		
		if(symbol == '1' || symbol == '2' || symbol == '3' || symbol == '4' || symbol == '5' || symbol == '6' || symbol == '7' || symbol == '8' || symbol == '9')
		{
			paintNumber(g2);
		}
		else if(symbol == 'N' || symbol == 'E' || symbol == 'W' || symbol == 'S' || symbol == 'C' || symbol == 'F')
		{
			paintCharacter(g2);
		}
	}

	public void paintNumber(Graphics2D g2)
	{
		g2.setFont(new Font("Roman", Font.PLAIN, 24));
		g2.setColor(Color.BLACK);
		g2.drawString(Character.toString(hMap.get(symbol)), 44, 35);
		g2.setColor(Color.RED);
		g2.drawString(Character.toString('\u842C'), 44, 60);
	}
	
	public void paintCharacter(Graphics2D g2)
	{
		g2.setFont(new Font("Roman", Font.PLAIN, 48));
		
		if(symbol == 'N' || symbol == 'E' || symbol == 'W' || symbol == 'S')
		{
			g2.setColor(Color.BLACK);
			g2.drawString(Character.toString(hMap.get(symbol)), 32, 62);
		}
		else if(symbol == 'C')
		{
			g2.setColor(Color.RED);
			g2.drawString(Character.toString(hMap.get(symbol)), 32, 62);
		}
		else if(symbol == 'F')
		{
			g2.setColor(Color.decode("#00CD00"));
			g2.drawString(Character.toString(hMap.get(symbol)), 32, 62);
		}
	}


	public boolean matches(Tile other)
	{
		if(this == other)
		{
			return true;
		}
		if(getClass() != other.getClass())
		{
			return false;
		}
	
		CharacterTile o = (CharacterTile)other;
			
		if(this.symbol == o.symbol)
		{
			return super.matches(other);
		}
		else
		{
			return false;
		}
	}
	
	public String toString()
	{
			return "Character: " + Character.toString(symbol);		
	}
}
