/*By Erika Fermin, CS 3230 spring 2019*/
import	java.awt.*;
import 	java.util.ArrayList;

public class CircleTile extends RankTile
{
	ArrayList<Circle> circles = new ArrayList<Circle>();
	
	public CircleTile(int rank)
	{
		super(rank);
		setToolTipText(toString());
	}
	
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		
		switch(rank)
		{
			case 1:
				circles = Circle1();
				break;
			case 2:
				circles = Circle2();
				break;
			case 3:
				circles = Circle3();
				break;
			case 4:
				circles = Circle4();
				break;
			case 5:
				circles = Circle5();
				break;
			case 6:
				circles = Circle6();
				break;
			case 7:
				circles = Circle7();
				break;
			case 8:
				circles = Circle8();
				break;
			case 9:
				circles = Circle9();
				break;
		}

		for (Circle c : circles)
			if (c != null)
				c.draw(g);
	}
	
	public ArrayList<Circle> Circle1()
	{
		circles.add(new Pancake(50, 33, 14, Color.RED));
		
		return circles;
	}
	
	public ArrayList<Circle> Circle2()
	{
		circles.add(new Circle(45, 15, 23, Color.decode("#008000")));
		circles.add(new Circle(45, 40, 23, Color.RED));
		
		return circles;
	}
	
	public ArrayList<Circle> Circle3()
	{
		circles.add(new Circle(25, 12, 23, Color.BLUE));
		circles.add(new Circle(45, 28, 23, Color.RED));
		circles.add(new Circle(65, 43, 23, Color.decode("#008000")));
		
		return circles;
	}
	
	public ArrayList<Circle> Circle4()
	{
		circles.add(new Circle(25, 12, 28, Color.BLUE));
		circles.add(new Circle(58, 12, 28, Color.decode("#008000")));
		circles.add(new Circle(58, 40, 28, Color.BLUE));
		circles.add(new Circle(25, 40, 28, Color.decode("#008000")));
		
		return circles;
	}
	
	public ArrayList<Circle> Circle5()
	{
		circles.add(new Circle(22, 12, 20, Color.BLUE));
		circles.add(new Circle(68, 12, 20, Color.decode("#008000")));
		circles.add(new Circle(45, 30, 20, Color.RED));
		circles.add(new Circle(22, 48, 20, Color.decode("#008000")));
		circles.add(new Circle(68, 48, 20, Color.BLUE));
		
		return circles;
	}
	
	public ArrayList<Circle> Circle6()
	{
		circles.add(new Circle(29, 11, 19, Color.decode("#008000")));
		circles.add(new Circle(29, 29, 19, Color.RED));
		circles.add(new Circle(29, 48, 19, Color.RED));
		circles.add(new Circle(60, 11, 19, Color.decode("#008000")));
		circles.add(new Circle(60, 29, 19, Color.RED));
		circles.add(new Circle(60, 48, 19, Color.RED));
		
		return circles;
	}
	
	public ArrayList<Circle> Circle7()
	{
		circles.add(new Circle(26, 15, 14, Color.decode("#008000")));
		circles.add(new Circle(48, 18, 14, Color.decode("#008000")));
		circles.add(new Circle(68, 21, 14, Color.decode("#008000")));
		circles.add(new Circle(32, 36, 14, Color.RED));
		circles.add(new Circle(32, 50, 14, Color.RED));
		circles.add(new Circle(62, 36, 14, Color.RED));
		circles.add(new Circle(62, 50, 14, Color.RED));
		
		return circles;
	}
	
	public ArrayList<Circle> Circle8()
	{
		circles.add(new Circle(32, 11, 14, Color.BLUE));
		circles.add(new Circle(32, 25, 14, Color.BLUE));
		circles.add(new Circle(32, 40, 14, Color.BLUE));
		circles.add(new Circle(32, 55, 14, Color.BLUE));
		circles.add(new Circle(62, 11, 14, Color.BLUE));
		circles.add(new Circle(62, 25, 14, Color.BLUE));
		circles.add(new Circle(62, 40, 14, Color.BLUE));
		circles.add(new Circle(62, 55, 14, Color.BLUE));
		
		return circles;
	}
	
	public ArrayList<Circle> Circle9()
	{
		circles.add(new Circle(23, 11, 20, Color.decode("#008000")));
		circles.add(new Circle(45, 11, 20, Color.decode("#008000")));
		circles.add(new Circle(68, 11, 20, Color.decode("#008000")));
		circles.add(new Circle(23, 30, 20, Color.RED));
		circles.add(new Circle(45, 30, 20, Color.RED));
		circles.add(new Circle(68, 30, 20, Color.RED));
		circles.add(new Circle(23, 49, 20, Color.BLUE));
		circles.add(new Circle(45, 49, 20, Color.BLUE));
		circles.add(new Circle(68, 49, 20, Color.BLUE));
		
		return circles;
	}
	
	public String toString()
	{
		return "Circle " + rank;
	}
}
