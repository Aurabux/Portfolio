/*By Erika Fermin, CS 3230 spring 2019*/
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.ArrayList;

public class BambooTile extends RankTile
{
	ArrayList<Bamboo> bamboos = new ArrayList<Bamboo>();
	int x = 55;
	int y = 40;
	
	public BambooTile(int rank)
	{
		super(rank);
		setToolTipText(toString());
	}
	
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);

		switch(rank)
		{
			case 2:
				bamboos = Bamboo2();
				break;
			case 3:
				bamboos = Bamboo3();
				break;
			case 4:
				bamboos = Bamboo4();
				break;
			case 5:
				bamboos = Bamboo5();
				break;
			case 6:
				bamboos = Bamboo6();
				break;
			case 7:
				bamboos = Bamboo7();
				break;
			case 8:
				bamboos = Bamboo8();
				break;
			case 9:
				bamboos = Bamboo9();
				break;
		}

		for (Bamboo b : bamboos)
			if (b != null)
				b.draw(g);
	}
	
	public ArrayList<Bamboo> Bamboo2()
	{
		bamboos.add(new Bamboo(x, y-11, Color.BLUE));
        bamboos.add(new Bamboo(x, y+11, Color.decode("#008000")));
        
		return bamboos;
	}
	
	public ArrayList<Bamboo> Bamboo3()
	{
		bamboos.add(new Bamboo(x,    y-11, Color.BLUE));
        bamboos.add(new Bamboo(x-10, y+11, Color.decode("#008000")));
        bamboos.add(new Bamboo(x+10, y+11, Color.decode("#008000")));
        
		return bamboos;
	}
	
	public ArrayList<Bamboo> Bamboo4()
	{
		bamboos.add(new Bamboo(x-10, y-13, Color.BLUE));
        bamboos.add(new Bamboo(x+10, y-13, Color.decode("#008000")));
        bamboos.add(new Bamboo(x+10, y+13, Color.BLUE));
        bamboos.add(new Bamboo(x-10, y+13, Color.decode("#008000")));
		
		return bamboos;
	}
	
	public ArrayList<Bamboo> Bamboo5()
	{
		bamboos.add(new Bamboo(x-15, y-13, Color.decode("#008000")));
        bamboos.add(new Bamboo(x+15, y-13, Color.BLUE));
        bamboos.add(new Bamboo(x, y, Color.RED));
        bamboos.add(new Bamboo(x+15, y+13, Color.decode("#008000")));
        bamboos.add(new Bamboo(x-15, y+13, Color.BLUE));
		
		return bamboos;
	}
	
	public ArrayList<Bamboo> Bamboo6()
	{
		bamboos.add(new Bamboo(x+13, y-13, Color.decode("#008000")));
		bamboos.add(new Bamboo(x-13, y-13, Color.decode("#008000")));
		bamboos.add(new Bamboo(x, y-13, Color.decode("#008000")));
        bamboos.add(new Bamboo(x, y+13, Color.BLUE));
        bamboos.add(new Bamboo(x-13, y+13, Color.BLUE));
        bamboos.add(new Bamboo(x+13, y+13, Color.BLUE));
		
		return bamboos;
	}
	
	public ArrayList<Bamboo> Bamboo7()
	{
		bamboos.add(new Bamboo(x,    y-17, Color.RED));
		bamboos.add(new Bamboo(x+13, y, Color.decode("#008000")));
        bamboos.add(new Bamboo(x,    y, Color.BLUE));
        bamboos.add(new Bamboo(x+13, y+17, Color.decode("#008000")));
        bamboos.add(new Bamboo(x-13, y+17, Color.decode("#008000")));
        bamboos.add(new Bamboo(x,    y+17, Color.BLUE));
        bamboos.add(new Bamboo(x-13, y, Color.decode("#008000")));
		
		return bamboos;
	}
	
	public ArrayList<Bamboo> Bamboo8()
	{
	    bamboos.add(new RotatedBamboo(45,  x+1, y-55, Color.decode("#008000")));
	    bamboos.add(new RotatedBamboo(-45, x-34, y+23, Color.decode("#008000")));
	    bamboos.add(new RotatedBamboo(-45, x-58, y+28, Color.BLUE));
	    bamboos.add(new RotatedBamboo(45,  x+25, y-49, Color.BLUE));
	    bamboos.add(new Bamboo(x-19, y-11, Color.decode("#008000")));
	    bamboos.add(new Bamboo(x+19, y-11, Color.decode("#008000")));
	    bamboos.add(new Bamboo(x-19, y+11, Color.BLUE));
	    bamboos.add(new Bamboo(x+19, y+11, Color.BLUE));
		
		return bamboos;
	}
	
	public ArrayList<Bamboo> Bamboo9()
	{
		bamboos.add(new Bamboo(x-13, y-17, Color.RED));
	    bamboos.add(new Bamboo(x,    y-17, Color.BLUE));
	    bamboos.add(new Bamboo(x+13, y-17, Color.decode("#008000")));
	    bamboos.add(new Bamboo(x-13, y, Color.RED));
	    bamboos.add(new Bamboo(x,    y, Color.BLUE));
	    bamboos.add(new Bamboo(x+13, y, Color.decode("#008000")));
	    bamboos.add(new Bamboo(x-13, y+17, Color.RED));
	    bamboos.add(new Bamboo(x,    y+17, Color.BLUE));
	    bamboos.add(new Bamboo(x+13, y+17, Color.decode("#008000")));
	    
		return bamboos;
	}
	
	public String toString()
	{
		return "Bamboo " + rank;
	}
}
